package ui;

import db.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class NotificationsTab extends JPanel {
    private JTable customerTable;
    private DefaultTableModel customerModel;
    private JTextField searchField;

    private JTable inactiveTable;
    private DefaultTableModel inactiveModel;

    public NotificationsTab() {
        setLayout(new BorderLayout());

        JTabbedPane subTabs = new JTabbedPane();
        subTabs.addTab("Customers", buildCrudPanel());
        subTabs.addTab("Inactive Customers", buildInactivePanel());

        add(subTabs, BorderLayout.CENTER);

        loadCustomers("");
        loadInactiveCustomers("");
    }

    private JPanel buildCrudPanel() {

        JPanel panel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        searchField = new JTextField(20);
        JButton addBtn = new JButton("Add New");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");

        topPanel.add(new JLabel("Search: "));
        topPanel.add(searchField);
        topPanel.add(addBtn);
        topPanel.add(editBtn);
        topPanel.add(deleteBtn);

        panel.add(topPanel, BorderLayout.NORTH);

        String[] cols = {"ID", "First Name", "Last Name", "Email", "Phone", "Country"};

        customerModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        customerTable = new JTable(customerModel);
        panel.add(new JScrollPane(customerTable), BorderLayout.CENTER);

        searchField.getDocument().addDocumentListener(
            new javax.swing.event.DocumentListener() {
                public void insertUpdate(javax.swing.event.DocumentEvent e) {
                    loadCustomers(searchField.getText().trim());
                }
                public void removeUpdate(javax.swing.event.DocumentEvent e) {
                    loadCustomers(searchField.getText().trim());
                }
                public void changedUpdate(javax.swing.event.DocumentEvent e) {
                    loadCustomers(searchField.getText().trim());
                }
            }
        );

        addBtn.addActionListener(e -> showCustomerDialog(null));

        editBtn.addActionListener(e -> {
            int row = customerTable.getSelectedRow();
            if (row != -1) {
                int id = (int) customerModel.getValueAt(row, 0);
                showCustomerDialog(id);
            } else {
                JOptionPane.showMessageDialog(this, "Select a customer.");
            }
        });

        deleteBtn.addActionListener(e -> {
            int row = customerTable.getSelectedRow();
            if (row != -1) {
                int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Delete selected customer?",
                    "Confirm",
                    JOptionPane.YES_NO_OPTION
                );

                if (confirm == JOptionPane.YES_OPTION) {
                    deleteCustomer((int) customerModel.getValueAt(row, 0));
                }
            }
        });

        return panel;
    }

    private JPanel buildInactivePanel() {

        JPanel panel = new JPanel(new BorderLayout());

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField inactiveSearch = new JTextField(20);
        JButton searchBtn = new JButton("Search");

        top.add(new JLabel("Search: "));
        top.add(inactiveSearch);
        top.add(searchBtn);

        panel.add(top, BorderLayout.NORTH);

        String[] cols = {"ID", "First Name", "Last Name", "Email", "Country", "Last Invoice"};

        inactiveModel = new DefaultTableModel(cols, 0);
        inactiveTable = new JTable(inactiveModel);

        panel.add(new JScrollPane(inactiveTable), BorderLayout.CENTER);

        searchBtn.addActionListener(e ->
            loadInactiveCustomers(inactiveSearch.getText().trim())
        );

        return panel;
    }

    private void loadCustomers(String search) {

        customerModel.setRowCount(0);

        String sql =
            "SELECT CustomerId, FirstName, LastName, Email, Phone, Country " +
            "FROM customer " +
            "WHERE FirstName LIKE ? OR LastName LIKE ? OR Email LIKE ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String p = "%" + search + "%";

            stmt.setString(1, p);
            stmt.setString(2, p);
            stmt.setString(3, p);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                customerModel.addRow(new Object[]{
                    rs.getInt("CustomerId"),
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("Email"),
                    rs.getString("Phone"),
                    rs.getString("Country")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


private void loadInactiveCustomers(String search) {

    inactiveModel.setRowCount(0);

    String sql = "SELECT c.CustomerId, c.FirstName, c.LastName, c.Email, c.Country, MAX(i.InvoiceDate) AS LastInvoice " +
                "FROM customer c " +
                "LEFT JOIN invoice i ON c.CustomerId = i.CustomerId " +
                "WHERE (c.FirstName LIKE ? OR c.LastName LIKE ? OR c.Email LIKE ?) " +
                "GROUP BY c.CustomerId, c.FirstName, c.LastName, c.Email, c.Country " +
                "HAVING (LastInvoice IS NULL OR LastInvoice < DATE_SUB(NOW(), INTERVAL 2 YEAR)) " +
                "ORDER BY LastInvoice ASC;";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        String p = "%" + search + "%";

        stmt.setString(1, p);
        stmt.setString(2, p);
        stmt.setString(3, p);

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {

            String last = rs.getString("LastInvoice");
            if (last == null) last = "Never";

            inactiveModel.addRow(new Object[]{
                rs.getInt("CustomerId"),
                rs.getString("FirstName"),
                rs.getString("LastName"),
                rs.getString("Email"),
                rs.getString("Country"),
                last
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading inactive customers: " + e.getMessage());
    }
}
    private void showCustomerDialog(Integer customerId) {

        JDialog dialog = new JDialog(
            (Frame) SwingUtilities.getWindowAncestor(this),
            customerId == null ? "Add Customer" : "Edit Customer",
            true
        );

        dialog.setSize(400, 300);
        dialog.setLayout(new GridLayout(6, 2, 10, 10));
        dialog.setLocationRelativeTo(this);

        JTextField fName = new JTextField();
        JTextField lName = new JTextField();
        JTextField email = new JTextField();
        JTextField phone = new JTextField();
        JTextField country = new JTextField();

        if (customerId != null) {
            try (Connection conn = DatabaseConnection.getConnection()) {

                PreparedStatement stmt =
                    conn.prepareStatement("SELECT * FROM customer WHERE CustomerId=?");

                stmt.setInt(1, customerId);

                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    fName.setText(rs.getString("FirstName"));
                    lName.setText(rs.getString("LastName"));
                    email.setText(rs.getString("Email"));
                    phone.setText(rs.getString("Phone"));
                    country.setText(rs.getString("Country"));
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        JButton save = new JButton("Save");
        JButton cancel = new JButton("Cancel");

        dialog.add(new JLabel("First Name")); dialog.add(fName);
        dialog.add(new JLabel("Last Name")); dialog.add(lName);
        dialog.add(new JLabel("Email")); dialog.add(email);
        dialog.add(new JLabel("Phone")); dialog.add(phone);
        dialog.add(new JLabel("Country")); dialog.add(country);
        dialog.add(save); dialog.add(cancel);

        save.addActionListener(e -> {

        String first = fName.getText().trim();
        String last = lName.getText().trim();
        String em = email.getText().trim();
        String ph = phone.getText().trim();
        String ctry = country.getText().trim();

        if (first.isEmpty() || last.isEmpty() || em.isEmpty() || ph.isEmpty() || ctry.isEmpty()) {
            JOptionPane.showMessageDialog(dialog, "All fields must be filled in.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {

            if (customerId == null) {

                PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO customer (FirstName, LastName, Email, Phone, Country) VALUES (?,?,?,?,?)"
                );

                stmt.setString(1, first);
                stmt.setString(2, last);
                stmt.setString(3, em);
                stmt.setString(4, ph);
                stmt.setString(5, ctry);

                stmt.executeUpdate();

            } else {

                PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE customer SET FirstName=?, LastName=?, Email=?, Phone=?, Country=? WHERE CustomerId=?"
                );

                stmt.setString(1, first);
                stmt.setString(2, last);
                stmt.setString(3, em);
                stmt.setString(4, ph);
                stmt.setString(5, ctry);
                stmt.setInt(6, customerId);

                stmt.executeUpdate();
            }

            dialog.dispose();
            loadCustomers("");
            loadInactiveCustomers("");

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    });

        cancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void deleteCustomer(int id) {

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt =
                 conn.prepareStatement("DELETE FROM customer WHERE CustomerId=?")) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

            loadCustomers("");
            loadInactiveCustomers("");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Cannot delete customer.");
        }
    }
}