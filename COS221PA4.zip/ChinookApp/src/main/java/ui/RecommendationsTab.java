package ui;

import db.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class RecommendationsTab extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JComboBox<ComboItem> customerBox;

    private JLabel totalSpentLabel;
    private JLabel totalPurchasesLabel;
    private JLabel lastPurchaseLabel;
    private JLabel favGenreLabel;


    static class ComboItem {
        int id;
        String name;

        ComboItem(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public String toString() {
            return name;
        }
    }

    public RecommendationsTab() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        header.setBackground(Color.WHITE);

        customerBox = new JComboBox<>();
        JButton refreshBtn = new JButton("Refresh");

        header.add(new JLabel("Customer:"));
        header.add(customerBox);
        header.add(refreshBtn);

        add(header, BorderLayout.NORTH);

        JPanel stats = new JPanel(new GridLayout(1, 4, 10, 10));
        stats.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        stats.setBackground(new Color(245, 247, 250));

        totalSpentLabel = createCard("Total Spent", "$0");
        totalPurchasesLabel = createCard("Purchases", "0");
        lastPurchaseLabel = createCard("Last Purchase", "-");
        favGenreLabel = createCard("Favourite Genre", "-");

        stats.add(totalSpentLabel);
        stats.add(totalPurchasesLabel);
        stats.add(lastPurchaseLabel);
        stats.add(favGenreLabel);

        add(stats, BorderLayout.CENTER);

        model = new DefaultTableModel(new String[]{"Recommended Tracks"}, 0);
        table = new JTable(model);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createTitledBorder("Recommendations"));

        add(scroll, BorderLayout.SOUTH);

        loadCustomers();

        customerBox.addActionListener(e -> updateAll());
        refreshBtn.addActionListener(e -> updateAll());
    }

    private JLabel createCard(String title, String value) {
        JLabel label = new JLabel("<html><b>" + title + "</b><br>" + value + "</html>");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        label.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        return label;
    }

    private void updateAll() {
        if (customerBox.getSelectedItem() == null) return;

        ComboItem selected = (ComboItem) customerBox.getSelectedItem();
        int id = selected.id;

        loadSummary(id);
        loadFavouriteGenre(id);
        loadRecommendations(id);
    }

    private void loadCustomers() {

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT CustomerId, FirstName, LastName FROM Customer")) {

        while (rs.next()) {

            int id = rs.getInt("CustomerId");

            String name = rs.getString("FirstName") + " " +
                        rs.getString("LastName");

            customerBox.addItem(new ComboItem(id, name));
        }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSummary(int customerId) {

        String sql =
            "SELECT SUM(Total) AS totalSpent, " +
            "COUNT(InvoiceId) AS totalPurchases, " +
            "MAX(InvoiceDate) AS lastPurchase " +
            "FROM invoice WHERE CustomerId = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                double spent = rs.getDouble("totalSpent");
                if (rs.wasNull()) spent = 0;

                int count = rs.getInt("totalPurchases");
                String last = rs.getString("lastPurchase");

                totalSpentLabel.setText("Total Spent: $" + spent);
                totalPurchasesLabel.setText("Purchases: " + count);
                lastPurchaseLabel.setText("Last Purchase: " +
                    (last != null ? last : "-"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadFavouriteGenre(int customerId) {

        String sql =
            "SELECT g.Name FROM invoice i " +
            "JOIN invoiceline il ON i.InvoiceId = il.InvoiceId " +
            "JOIN track t ON il.TrackId = t.TrackId " +
            "JOIN genre g ON t.GenreId = g.GenreId " +
            "WHERE i.CustomerId = ? " +
            "GROUP BY g.Name " +
            "ORDER BY COUNT(*) DESC LIMIT 1";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                favGenreLabel.setText("Favourite Genre: " + rs.getString("Name"));
            } else {
                favGenreLabel.setText("Favourite Genre: -");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadRecommendations(int customerId) {

        model.setRowCount(0);

        String sql =
            "SELECT t.Name FROM track t " +
            "WHERE t.GenreId = (" +
            "  SELECT GenreId FROM (" +
            "    SELECT tr.GenreId FROM invoice i " +
            "    JOIN invoiceline il ON i.InvoiceId = il.InvoiceId " +
            "    JOIN track tr ON il.TrackId = tr.TrackId " +
            "    WHERE i.CustomerId = ? " +
            "    GROUP BY tr.GenreId " +
            "    ORDER BY COUNT(*) DESC LIMIT 1" +
            "  ) x" +
            ") " +
            "AND t.TrackId NOT IN (" +
            "  SELECT il.TrackId FROM invoice i " +
            "  JOIN invoiceline il ON i.InvoiceId = il.InvoiceId " +
            "  WHERE i.CustomerId = ?" +
            ") LIMIT 10";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            ps.setInt(2, customerId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("Name")});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}